package com.vmware.vim25.mo.samples;

public class allmain {
	 public static void main(String[] args) throws Exception 
	  {
		 allmeth am = new allmeth();
		 am.HelloVM();
	  }
}
