package CONFIG;

public class SJSULAB
{
    
    public static String getVmwareHostURL() { return "https://cmpe-admin3.engr.sjsu.edu/sdk" ; }
    public static String getVmwareLogin() { return "students" ; }
    public static String getVmwarePassword() { return "virtual$admin@sjsu" ; }
    public static String getVmwareVM() { return "paul@nguyenresearch.com" ; }

    public static String getOracleHostURL() { return "http://cmpe-admin2.engr.sjsu.edu:8888/" ; }
    public static String getOracleContextPath() { return "OVSWS" ; }
    public static String getOracleLogin() { return "Students" ; }
    public static String getOraclePassword() { return "cmpe290" ; }
    public static String getOracleVM() { return "<tbd>" ; }

        
    
}
